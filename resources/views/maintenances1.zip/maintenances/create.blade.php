@extends('layouts.app')

@section('content')
<div class="container">
    <h2>Add Maintenance Record</h2>

    <form action="{{ route('maintenances.store') }}" method="POST">
        @csrf
        <div class="mb-3">
            <label>Aircraft Model</label>
            <input type="text" name="aircraft_model" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Registration Number</label>
            <input type="text" name="registration_number" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Issue Description</label>
            <textarea name="issue_description" class="form-control" required></textarea>
        </div>
        <div class="mb-3">
            <label>Maintenance Date</label>
            <input type="date" name="maintenance_date" class="form-control" required>
        </div>
        <button class="btn btn-success">Save</button>
    </form>
</div>
@endsection
