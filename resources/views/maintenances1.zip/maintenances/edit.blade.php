@extends('layouts.app')

@section('content')
<div class="container">
    <h2>Edit Maintenance Status</h2>

    <form action="{{ route('maintenances.update', $maintenance->id) }}" method="POST">
        @csrf @method('PUT')

        <div class="mb-3">
            <label>Status</label>
            <select name="status" class="form-control">
                <option {{ $maintenance->status == 'Pending' ? 'selected' : '' }}>Pending</option>
                <option {{ $maintenance->status == 'In Progress' ? 'selected' : '' }}>In Progress</option>
                <option {{ $maintenance->status == 'Completed' ? 'selected' : '' }}>Completed</option>
            </select>
        </div>

        <div class="mb-3">
            <label>Remarks</label>
            <textarea name="remarks" class="form-control">{{ $maintenance->remarks }}</textarea>
        </div>

        <button class="btn btn-primary">Update</button>
    </form>
</div>
@endsection
