@extends('layout')

@section('content')
<div class="container mt-5 mb-5">
    <h2>Aircraft Maintenance Records</h2>

    <a href="{{ route('maintenances.create') }}" class="btn btn-primary mb-3">Add Maintenance</a>

    @if (session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
    @endif

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Aircraft</th>
                <th>Registration</th>
                <th>Issue</th>
                <th>Date</th>
                <th>Status</th>
                <th>Remarks</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($maintenances as $m)
                <tr>
                    <td>{{ $m->aircraft_model }}</td>
                    <td>{{ $m->registration_number }}</td>
                    <td>{{ $m->issue_description }}</td>
                    <td>{{ $m->maintenance_date }}</td>
                    <td>{{ $m->status }}</td>
                    <td>{{ $m->remarks }}</td>
                    <td>
                        <a href="{{ route('maintenances.edit', $m->id) }}" class="btn btn-sm btn-warning">Edit</a>
                        <form action="{{ route('maintenances.destroy', $m->id) }}" method="POST" class="d-inline">
                            @csrf @method('DELETE')
                            <button class="btn btn-sm btn-danger" onclick="return confirm('Delete this record?')">Delete</button>
                        </form>
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>

    {{ $maintenances->links() }}
</div>
@endsection
